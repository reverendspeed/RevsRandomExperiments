/*
 README
  This file must remain encoded as utf-8
  The program will generate a pleasing connected pattern using U+2500 through U+257F
  which may then be displayed using the Knots typeface.

 LICENCE
 * knotgen.cpp is authored and maintained by Ben Griffin ben.AT.redsnapper.DOT.net
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 3 of the License, or (at your option)
 * any later version.
 *
 * This program is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for
 * more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 
  COMPILATION
	The program should compile with eg: g++ knotgen.cpp -o knotgen
	
  USAGE
	The program takes from two to seven numeric parameters. Each one affects the knotwork generated.
	Parm 1: Width. The number of characters wide. It must be more than 1.
	Parm 2: Height. The number of characters high. It must be more than 1.
	Parm 3: Border. If this is more than 0, then the knotwork will be a border this thick.
	Parm 4: Style.  This is a value beteen 0 and 100. 0 = All twists, 100=all straights. Default is 33.
	Parm 5: Tile.   0= no tiling, 1=horizontal only, 2=vertical only, 3= both.
	Parm 6: Mirror. 0= no mirror, 1=horizontal only, 2=vertical only, 3= both.
	Spaces: Put empty cells into the knotwork.; not properly supported.
*/

#include <iostream>
#include <sstream>
#include <time.h>               // For time function (random seed)
#include <stdlib.h>             // For rand and srand functions.


using namespace std;  //introduces namespace std
//--------------------------------------------------------------------
typedef enum directions {north,east,south,west,none} direction;
typedef enum doorwaystyles {crossed,straight,blocked} doorwaystyle;

#define nil 0

class Cell {
public:
	static doorwaystyle	GetStyle(int style,bool);
	doorwaystyle	GetStyle(direction d);
	void			GetMapping(ostringstream&,int);
	void			SetStyle(direction d,doorwaystyle s);
	void			EnterCell(direction from,doorwaystyle s);
	void			SetCellXY(int x,int y);
	pair<int,int>	GetCellXY();
	bool			CellEnteredQ();
	direction		GetEntryWall();
	
private:
	bool			entered;
	pair<int,int>	context;
	direction 		EntryWall;
	doorwaystyle	NorthWall;
	doorwaystyle 	SouthWall;
	doorwaystyle 	EastWall;
	doorwaystyle 	WestWall;
};

void			Cell::SetCellXY(int x,int y) {context.first=x; context.second=y; entered=false; NorthWall=blocked; SouthWall=blocked; EastWall=blocked; WestWall=blocked; EntryWall=none;}
pair<int,int>	Cell::GetCellXY() {return context;}
direction		Cell::GetEntryWall() {return EntryWall;}

//style is a maze setting, indicating the proportion of crossed vs straight.
doorwaystyle Cell::GetStyle(int style,bool block)  {
	doorwaystyle value = blocked;
	switch (style) {
		case 0: value=crossed; break;
		case 100: value=straight; break;
		default:
			if (rand() % 100 < style)
				value = straight;
			else
				value = crossed;
			break;
	}
	if (block && rand() % 100 < 50) {
		value = blocked;
	} 	
	return value;
}

doorwaystyle Cell::GetStyle(direction d)  {
	doorwaystyle value=blocked;
	switch(d) {
		case north:value= NorthWall; break;
		case south:value= SouthWall; break;
		case east: value= EastWall; break;
		case west: value= WestWall; break;
		case none: value= blocked; break;
	}
	return value;
}

void Cell::SetStyle(direction d,doorwaystyle s)  {
	switch(d) {
		case north: NorthWall=s; break;
		case south: SouthWall=s; break;
		case east:  EastWall=s; break;
		case west:  WestWall=s; break;
		case none:  break;
	}
}

void Cell::EnterCell(direction from, doorwaystyle s) {
	EntryWall=from;
	entered=true;
	SetStyle(from,s);
}

void Cell::GetMapping(ostringstream& o,int border) {
	switch (NorthWall) {
		case straight: {
			switch (SouthWall) {
				case straight: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight: o << "╋"; break;
								case crossed: o << "╉"; break;
								case blocked: o << "┫"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight: o << "╊"; break;
								case crossed: o << "╂"; break;
								case blocked: o << "┨"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight: o << "┣"; break;
								case crossed: o << "┠"; break;
								case blocked: o << "┃"; break;
							}
						} break;
					}
				} break;
				case crossed: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "╇"; break;
								case crossed: o << "╃"; break;
								case blocked: o << "┩"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "╄"; break;
								case crossed: o << "╀"; break;
								case blocked: o << "┦"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "┡"; break;
								case crossed: o << "┞"; break;
								case blocked: o << "╿"; break;
							}
						} break;
					}
				} break;
				case blocked: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "┻"; break;
								case crossed: o << "┹"; break;
								case blocked: o << "┛"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "┺"; break;
								case crossed: o << "┸"; break;
								case blocked: o << "┚"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "┗"; break;
								case crossed: o << "┖"; break;
								case blocked: o << "╏"; break;
							}
						} break;
					}
				} break;
			}
		} break;
		case crossed: {
			switch (SouthWall) {
				case straight: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "╈"; break;
								case crossed: o << "╅"; break;
								case blocked: o << "┪"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "╆"; break;
								case crossed: o << "╁"; break;
								case blocked: o << "┧"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "┢"; break;
								case crossed: o << "┟"; break;
								case blocked: o << "╽"; break;
							}
						} break;
					}
				} break;
				case crossed: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "┿"; break;
								case crossed: o << "┽"; break;
								case blocked: o << "┥"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "┾"; break;
								case crossed: o << "┼"; break;
								case blocked: o << "┤"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "┝"; break;
								case crossed: o << "├"; break;
								case blocked: o << "│"; break;
							}
						} break;
					}
				} break;
				case blocked: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "┷"; break;
								case crossed: o << "┵"; break;
								case blocked: o << "┙"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "┶"; break;
								case crossed: o << "┴"; break;
								case blocked: o << "┘"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "┕"; break;
								case crossed: o << "└"; break;
								case blocked: o << "┈"; break;
							}
						} break;
					}
				} break;
			}
		} break;
		case blocked: {
			switch (SouthWall) {
				case straight: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "┳"; break;
								case crossed: o << "┱"; break;
								case blocked: o << "┓"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "┲"; break;
								case crossed: o << "┰"; break;
								case blocked: o << "┒"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "┏"; break;
								case crossed: o << "┎"; break;
								case blocked: o << "╻"; break;
							}
						} break;
					}
				} break;
				case crossed: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "┯"; break;
								case crossed: o << "┭"; break;
								case blocked: o << "┑"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "┮"; break;
								case crossed: o << "┬"; break;
								case blocked: o << "┐"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "┍"; break;
								case crossed: o << "┌"; break;
								case blocked: o << "╷"; break;
							}
						} break;
					}
				} break;
				case blocked: {
					switch (WestWall) {
						case straight: {
							switch (EastWall) {
								case straight:o << "━"; break;
								case crossed: o << "╾"; break;
								case blocked: o << "╸"; break;
							}
						} break;
						case crossed: {
							switch (EastWall) {
								case straight:o << "╼"; break;
								case crossed: o << "─"; break;
								case blocked: o << "╴"; break;
							}
						} break;
						case blocked: {
							switch (EastWall) {
								case straight:o << "╺"; break;
								case crossed: o << "╶"; break;
								case blocked: o << "╳"; break;
							}
						} break;
					}
				} break;
			}
		} break;
	}
}	

bool Cell::CellEnteredQ() {
	return entered;
}

//--------------------------------------------------------------------
class Maze {
public:
	Maze(int w,int h,int b,int s,int y,int t,int m);
	~Maze();
	void Create();
	void Create(int x,int y);
	void Print();
private:
	Cell * MazeP(int x,int y);  
	Cell * MazeP(Cell *p,direction d);
	bool MazeQ(Cell *p,direction d);
	Cell *space;
	int width;
	int height;
	int border;
	int spaces;
	int style;
	int tile;
	int mirror;
};

Maze::Maze(int w,int h,int b,int s,int y,int t, int m) {
	Cell *CurrentCell;	
    srand((unsigned)time(NULL));
	width=w; height=h; border=b; spaces=s; style=y; tile=t; mirror=m;
	space=new Cell [w*h];
	for (int j=0; j < width; j++) {
		for (int i=0; i< height; i++) {
			CurrentCell=MazeP(j,i);
			CurrentCell->SetCellXY(j,i);
		}
	}
	
	//The below creates a border
	if (border > 0) {
		for (int j=(border); j < width-border; j++) {
			for (int i=(border); i< height-border; i++) {
				CurrentCell=MazeP(j,i);	
				CurrentCell->EnterCell(none,blocked);
			}
		}
	}
	//The below adds random spaces
	for (int j=0; j < spaces; j++) {
		CurrentCell=MazeP(rand() % width,rand() % height);	
		CurrentCell->EnterCell(none,blocked);
	}
}

Maze::~Maze() {delete [] space;}
void Maze::Create() {
	int x = (rand() % width);	
	int y = (rand() % height);
	Create(x,y);
}


void Maze::Create(int x,int y) {
	direction backtrack=north;
	Cell *CurrentCell;
	bool N,S,E,W;
	direction dirs[4];
	direction history=none;	//Used as bias to stop lines continuing in the same direction
	int hist1=0,hist2=0;
	
	if (border > 0)
		CurrentCell=MazeP(x,0);	
	else
		CurrentCell=MazeP(x,y);	
	CurrentCell->EnterCell(none,blocked);
	do {
		int count=0;
		E=MazeQ(CurrentCell, east); if (!E) dirs[count++]=east;
		S=MazeQ(CurrentCell,south); if (!S) dirs[count++]=south;
		W=MazeQ(CurrentCell, west); if (!W) dirs[count++]=west;
		N=MazeQ(CurrentCell,north); if (!N) dirs[count++]=north;
		if (count > 2 && hist1>2 && hist2>2) {
			count = 0;
		}
		if (count > 0) {
			doorwaystyle newstyle = Cell::GetStyle(style,false);
			direction to = dirs[rand() % count];
			if (history == to && count > 1 && (rand() %2 > 0))	// 50% chance of change of direction
				while (history == to ) to = dirs[rand() % count];
			direction from=none;
			switch (to) {
				case north: from=south; break;
				case south: from=north; break;
				case east: from=west; break;
				case west: from=east;
			}
			CurrentCell->SetStyle(to,newstyle);
			CurrentCell=MazeP(CurrentCell,to);
			CurrentCell->EnterCell(from,newstyle);
			history = to;
		} else {
			backtrack=CurrentCell->GetEntryWall();
			CurrentCell=MazeP(CurrentCell,backtrack);
		}
		hist2=hist1; hist1=count;
	}
	while (backtrack != none);
	if (mirror > 0) {
		if ((mirror & 1) == 1) {	//Horizontal mirror
			for (int i=0; i<width; i++) {
				for (int j=0; j < height; j++) {
					if ((width % 2 == 1) && i == ((width-1)/2)) {
						CurrentCell=MazeP(i,j);
						doorwaystyle Wstyle = CurrentCell->GetStyle(west);
						CurrentCell->SetStyle(east,Wstyle);						
						CurrentCell=MazeP(i+1,j);
						CurrentCell->SetStyle(west,Wstyle);
					} else {
						CurrentCell=MazeP(i,j);
						doorwaystyle Wstyle = CurrentCell->GetStyle(west);
						doorwaystyle Nstyle = CurrentCell->GetStyle(north);
						doorwaystyle Sstyle = CurrentCell->GetStyle(south);
						doorwaystyle Estyle = CurrentCell->GetStyle(east);
						CurrentCell=MazeP((width-1)-i,j);
						if (Estyle != blocked) CurrentCell->SetStyle(west,Estyle);
						if (Nstyle != blocked) CurrentCell->SetStyle(north,Nstyle);
						if (Sstyle != blocked) CurrentCell->SetStyle(south,Sstyle);
						if (Wstyle != blocked) CurrentCell->SetStyle(east,Wstyle);
					}
				}
			}
		}
		if ((mirror & 2) == 2) {		//Vertical mirror
			for (int i=0; i<width; i++) {
				for (int j=0; j < height; j++) {
					if ((height % 2 == 1) && j == ((height-1)/2)) {
						CurrentCell=MazeP(i,j);
						doorwaystyle Nstyle = CurrentCell->GetStyle(north);
						CurrentCell->SetStyle(south,Nstyle);
						CurrentCell=MazeP(i,j+1);
						CurrentCell->SetStyle(north,Nstyle);
					} else {
						CurrentCell=MazeP(i,j);
						doorwaystyle Wstyle = CurrentCell->GetStyle(west);
						doorwaystyle Nstyle = CurrentCell->GetStyle(north);
						doorwaystyle Sstyle = CurrentCell->GetStyle(south);
						doorwaystyle Estyle = CurrentCell->GetStyle(east);
						CurrentCell=MazeP(i,(height-1)-j);
						if (Wstyle != blocked) CurrentCell->SetStyle(west,Wstyle);
						if (Sstyle != blocked) CurrentCell->SetStyle(north,Sstyle);
						if (Nstyle != blocked) CurrentCell->SetStyle(south,Nstyle);
						if (Estyle != blocked) CurrentCell->SetStyle(east,Estyle);
					}
				}
			}
		}
	}
	if (tile > 0) {
		if (tile % 2 == 1) {	//Horizontal tiling
			for (int i=0; i < height; i++ ) {
				doorwaystyle newstyle = Cell::GetStyle(style,true);
				MazeP(0,i)->SetStyle(west,newstyle);
				MazeP(width-1,i)->SetStyle(east,newstyle);
			}
		}
		if (tile > 1) {		//Vertical tiling
			for (int i=0; i < width; i++ ) {
				doorwaystyle newstyle = Cell::GetStyle(style,true);
				MazeP(i,0)->SetStyle(north,newstyle);
				MazeP(i,height-1)->SetStyle(south,newstyle);
			}
		}
	}
}

Cell* Maze::MazeP(int x,int y)	//horizontal, vertical
{
	int pos=0;
	if (x<0 || x > width-1 || y < 0 || y > height-1) return nil;
	pos =x*height+y;
	return &space[pos];
}

Cell* Maze::MazeP(Cell *p,direction d) {
	pair<int,int> pos= p->GetCellXY();
	switch (d) {
		case north: pos.second--; break;
		case south: pos.second++; break;
		case  east: pos.first++; break;
		case  west: pos.first--; break;
		case  none: break; 
		default: break;
	}
	return MazeP(pos.first,pos.second);		
}

bool Maze::MazeQ(Cell *from,direction dir) {
	Cell *temp;
	bool entered=true;
	
	temp = MazeP(from,dir);
	if (temp != nil)
	{
		entered = temp->CellEnteredQ();
	}
	return entered;
}

void Maze::Print() {
	Cell *CurrentCell;
	ostringstream o;
	for (int i=0; i< height; i++) {
		for (int j=0; j< width; j++) {
			CurrentCell=MazeP(j,i);
			CurrentCell->GetMapping(o,border);
		}
		o << endl;
	}
	cout << o.str();
}
#pragma mark -

//--------------------------------------------------------------------
int main(int argc, char *argv[]) {	
	int width=3; int height=2; int border=0; int spaces=0; int style=33; int tile=0; int mirror=0;
	if (( argc < 3 ) || (argv[1][0] == '-' && argv[1][1] == '?')) {
		cout << "This takes from two to seven numeric parameters. Each one affects the knotwork generated." << std::endl;
		cout << "Parm 1: Width. The number of characters wide. It must be more than 1." << endl;
		cout << "Parm 2: Height. The number of characters high. It must be more than 1." << endl;
		cout << "Parm 3: Border. If this is more than 0, then the knotwork will be a border this thick." << endl;
		cout << "Parm 4: Style.  This is a value beteen 0 and 100. 0 = All twists, 100=all straights. Default is 33." << endl;
		cout << "Parm 5: Tile.   0= no tiling, 1=horizontal only, 2=vertical only, 3= both." << endl;
		cout << "Parm 6: Mirror. 0= no mirror, 1=horizontal only, 2=vertical only, 3= both." << endl;
	} 
	if (argc > 1) width=atoi(argv[1]);
	if (argc > 2) height=atoi(argv[2]);
	if (argc > 3) border=atoi(argv[3]);
	if (argc > 4) style=atoi(argv[4]);
	if (argc > 5) tile=atoi(argv[5]); 
	if (argc > 6) mirror=atoi(argv[6]); 
	if (width < 2) width=2;
	if (height < 2) height=2;
	if (style > 100 ) height=100;
	tile = tile % 4;
	mirror = mirror % 4;
	
	Maze myMaze(width,height,border,spaces,style,tile,mirror);	
	myMaze.Create();
	cout << endl;	
	myMaze.Print();
	cout << endl;
	return 0;
}

